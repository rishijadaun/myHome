<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('images/favicon.png') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('images/apple-touch-icon.png') }}">
    <link rel="manifest" href="{{ asset('manifest.json') }}">
    <meta name="theme-color" content="#4bb59d">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>@yield('title', 'Broker Panel') - SpaceSeeks</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        .gradient-text { background: linear-gradient(135deg, #4bb59d 0%, #3a9a85 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .tap-effect { transition: all 0.2s; }
        .tap-effect:active { transform: scale(0.96); }
        .sidebar-link.active { background-color: #e6f7f3; color: #4bb59d; font-weight: 600; }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
        }
        /* Custom scrollbar */
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
    @stack('styles')
</head>
<body class="bg-gray-50 font-sans text-gray-900 antialiased min-h-screen">

    <!-- Mobile Top Bar -->
    <div class="lg:hidden fixed top-0 left-0 right-0 bg-white border-b border-gray-100 z-40 px-4 py-3 flex items-center justify-between shadow-sm">
        <button onclick="toggleSidebar()" class="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center tap-effect" aria-label="Open Menu">
            <i class="fas fa-bars text-gray-700"></i>
        </button>
        <div class="flex items-center gap-2">
            <img src="{{ asset('images/spaceseeks-logo.png') }}" alt="SpaceSeeks" class="h-7 w-auto object-contain">
            <span class="text-brand text-xs font-bold bg-brand-50 px-2 py-0.5 rounded-md border border-brand-100">Broker</span>
        </div>
        <a href="{{ route('broker.bookings') }}" class="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center tap-effect relative" aria-label="Notifications">
            <i class="fas fa-bell text-gray-700"></i>
            <span class="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white"></span>
        </a>
    </div>

    <!-- Sidebar -->
    <aside class="sidebar fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-100 z-50 transition-transform duration-300 lg:translate-x-0 flex flex-col justify-between shadow-lg lg:shadow-none">
        <div>
            <div class="p-6 border-b border-gray-100 flex items-center justify-between">
                <a href="{{ route('broker.dashboard') }}" class="flex flex-col gap-1">
                    <img src="{{ asset('images/spaceseeks-logo.png') }}" alt="SpaceSeeks" class="h-8 w-auto object-contain object-left">
                    <!-- <div class="text-[11px] text-brand font-bold tracking-wider uppercase pl-1">Partner Broker Portal</div> -->
                </a>
                <button onclick="toggleSidebar()" class="lg:hidden w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center tap-effect">
                    <i class="fas fa-times text-gray-500 text-sm"></i>
                </button>
            </div>

            <nav class="p-4 space-y-1">
                <a href="{{ route('broker.dashboard') }}" class="sidebar-link {{ request()->routeIs('broker.dashboard') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                    <i class="fas fa-chart-line w-5 text-center"></i>
                    <span class="text-sm font-medium">Dashboard</span>
                </a>
                <a href="{{ route('broker.pgs') }}" class="sidebar-link {{ request()->routeIs('broker.pgs') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                    <i class="fas fa-building w-5 text-center"></i>
                    <span class="text-sm font-medium">My Properties</span>
                    <span class="ml-auto bg-brand text-white text-xs font-bold px-2 py-0.5 rounded-full">{{ $brokerSidebarStats['properties'] ?? 0 }}</span>
                </a>
                <a href="{{ route('broker.bookings') }}" class="sidebar-link {{ request()->routeIs('broker.bookings') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                    <i class="fas fa-calendar-check w-5 text-center"></i>
                    <span class="text-sm font-medium">Bookings</span>
                    @if(($brokerSidebarStats['pendingBookings'] ?? 0) > 0)
                        <span class="ml-auto bg-yellow-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{{ $brokerSidebarStats['pendingBookings'] }}</span>
                    @endif
                </a>
                <a href="{{ route('broker.tenants') }}" class="sidebar-link {{ request()->routeIs('broker.tenants') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                    <i class="fas fa-users w-5 text-center"></i>
                    <span class="text-sm font-medium">Tenants</span>
                    <span class="ml-auto bg-blue-50 text-blue-600 text-xs font-bold px-2 py-0.5 rounded-full">{{ $brokerSidebarStats['tenants'] ?? 0 }}</span>
                </a>
                <!-- <a href="{{ route('broker.earnings') }}" class="sidebar-link {{ request()->routeIs('broker.earnings') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                    <i class="fas fa-rupee-sign w-5 text-center"></i>
                    <span class="text-sm font-medium">Earnings</span>
                </a> -->
                <a href="{{ route('broker.reviews') }}" class="sidebar-link {{ request()->routeIs('broker.reviews') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                    <i class="fas fa-star w-5 text-center"></i>
                    <span class="text-sm font-medium">Reviews</span>
                    <span class="ml-auto bg-yellow-50 text-yellow-600 text-xs font-bold px-2 py-0.5 rounded-full">{{ $brokerSidebarStats['rating'] ?? '4.8 ★' }}</span>
                </a>
            </nav>
        </div>

        <div class="p-4 border-t border-gray-100 space-y-1">
            @if(Auth::check())
            <div class="px-3 py-2.5 mb-2 bg-brand-50/60 border border-brand-100/80 rounded-xl flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-brand to-brand-dark text-white flex items-center justify-center font-bold text-sm shadow-sm shadow-brand/30 shrink-0">
                    {{ strtoupper(substr(Auth::user()->profile->first_name ?? Auth::user()->name ?? 'B', 0, 1)) }}
                </div>
                <div class="overflow-hidden min-w-0">
                    <div class="text-xs font-bold text-gray-900 truncate">{{ Auth::user()->profile->first_name ?? 'Partner' }} {{ Auth::user()->profile->last_name ?? 'Broker' }}</div>
                    <div class="text-[10px] text-brand-dark font-medium truncate">{{ Auth::user()->email }}</div>
                </div>
            </div>
            @endif
            <div class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Account</div>
            <a href="{{ route('broker.profile') }}" class="sidebar-link {{ request()->routeIs('broker.profile') ? 'active' : '' }} flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                <i class="fas fa-user-circle w-5 text-center"></i>
                <span class="text-sm font-medium">Profile & Settings</span>
            </a>
            <form id="brokerLogoutForm" action="{{ route('broker.logout') }}" method="POST" class="hidden">
                @csrf
            </form>
            <a href="{{ route('broker.logout') }}" onclick="performBrokerLogout(event)" class="sidebar-link flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition cursor-pointer">
                <i class="fas fa-sign-out-alt w-5 text-center"></i>
                <span class="text-sm font-medium">Logout</span>
            </a>
        </div>
    </aside>

    <!-- Sidebar Overlay for Mobile -->
    <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 hidden lg:hidden transition-opacity" onclick="toggleSidebar()"></div>

    <!-- Main Content Area -->
    <div class="lg:ml-64 pt-16 lg:pt-0 min-h-screen flex flex-col justify-between">
        <main>
            @yield('content')
        </main>

        <footer class="bg-white border-t border-gray-100 py-4 px-8 text-center md:flex md:justify-between text-xs text-gray-500 mt-12">
            <div>&copy; {{ date('Y') }} SpaceSeeks Technologies. All rights reserved.</div>
            <div class="mt-2 md:mt-0 space-x-4">
                <a href="{{ route('user.home') }}" class="hover:text-brand transition">User Home</a>
                <a href="{{ route('broker.dashboard') }}" class="hover:text-brand transition">Broker Portal</a>
                <a href="#" class="hover:text-brand transition">Support</a>
            </div>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        window.getBrokerCsrfToken = function() {
            return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '{{ csrf_token() }}';
        };

        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            sidebar.classList.toggle('open');
            overlay.classList.toggle('hidden');
        }

        async function performBrokerLogout(e) {
            if (e) e.preventDefault();

            // Clear client-side stored tokens & profile
            localStorage.removeItem('staynest_token');
            localStorage.removeItem('staynest_user');
            localStorage.removeItem('broker_token');
            localStorage.removeItem('broker_user');

            window.location.href = "{{ route('broker.logout') }}";
        }
    </script>
    @stack('scripts')
</body>
</html>
