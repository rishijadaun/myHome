@extends('user.layouts.app')

@section('title', 'Sunrise Premium PG - StayNest')

@push('styles')
<style>
    .photo-grid-item {
        transition: filter 0.2s ease;
    }
    .photo-grid:hover .photo-grid-item {
        filter: brightness(0.9);
    }
    .photo-grid:hover .photo-grid-item:hover {
        filter: brightness(1.05);
    }
</style>
@endpush

@section('content')
<div class="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 pt-4 pb-24 md:pb-16">

    <!-- ================= 1. LISTING HEADER (DESKTOP & MOBILE) ================= -->
    <div class="mb-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-2">
            <div>
                <h1 class="text-xl sm:text-2xl md:text-3xl font-extrabold text-gray-900">Sunrise Premium PG & Co-living</h1>
                <div class="flex flex-wrap items-center gap-2 sm:gap-3 text-xs sm:text-sm text-gray-600 mt-1">
                    <span class="flex items-center gap-1 font-bold text-gray-900">
                        <i class="fas fa-star text-yellow-400"></i> 4.89
                    </span>
                    <span>•</span>
                    <a href="#reviews" class="font-bold underline text-gray-900 hover:text-brand transition">120 reviews</a>
                    <span>•</span>
                    <span class="bg-brand-50 text-brand font-bold px-2.5 py-0.5 rounded-full border border-brand/20">
                        <i class="fas fa-crown text-amber-500 mr-0.5"></i> Guest favourite
                    </span>
                    <span>•</span>
                    <span class="text-gray-500"><i class="fas fa-map-marker-alt text-brand mr-1"></i>Sector 62, Noida, Delhi NCR</span>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <button onclick="navigator.clipboard.writeText(window.location.href); alert('Listing link copied to clipboard!');" class="flex items-center gap-1.5 px-3.5 py-2 hover:bg-gray-100 rounded-xl text-xs font-semibold text-gray-700 transition tap-effect">
                    <i class="fas fa-arrow-up-from-bracket"></i> Share
                </button>
                <button onclick="toggleSaveDetail(this)" class="flex items-center gap-1.5 px-3.5 py-2 hover:bg-gray-100 rounded-xl text-xs font-semibold text-gray-700 transition tap-effect">
                    <i class="far fa-heart text-red-500"></i> <span id="saveLabel">Save</span>
                </button>
            </div>
        </div>
    </div>

    <!-- ================= 2. AIRBNB-STYLE 5-PHOTO MOSAIC GALLERY (DESKTOP) & SWIPER (MOBILE) ================= -->
    <!-- Mobile Image Slider -->
    <div class="md:hidden relative h-72 rounded-2xl overflow-hidden mb-6 shadow-sm">
        <img src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Sunrise PG" class="w-full h-full object-cover">
        <div class="absolute bottom-3 right-3 bg-black/70 backdrop-blur-md text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5">
            <i class="fas fa-images"></i> 1/8 photos
        </div>
    </div>

    <!-- Desktop 5-Photo Mosaic Grid -->
    <div class="hidden md:grid grid-cols-4 grid-rows-2 gap-2 h-[420px] rounded-3xl overflow-hidden mb-10 photo-grid relative">
        <!-- Main Large Photo (2 cols, 2 rows) -->
        <div class="col-span-2 row-span-2 relative overflow-hidden cursor-pointer photo-grid-item">
            <img src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Main Room" class="w-full h-full object-cover">
        </div>
        <!-- 4 Grid Photos -->
        <div class="relative overflow-hidden cursor-pointer photo-grid-item">
            <img src="https://images.unsplash.com/photo-1598928506311-c55ded91a20c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Bedroom" class="w-full h-full object-cover">
        </div>
        <div class="relative overflow-hidden cursor-pointer photo-grid-item">
            <img src="https://images.unsplash.com/photo-1505691938895-1758d7feb511?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Living Area" class="w-full h-full object-cover">
        </div>
        <div class="relative overflow-hidden cursor-pointer photo-grid-item">
            <img src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Dining Area" class="w-full h-full object-cover">
        </div>
        <div class="relative overflow-hidden cursor-pointer photo-grid-item">
            <img src="https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Balcony View" class="w-full h-full object-cover">
        </div>
        <!-- Show All Photos Button -->
        <button class="absolute bottom-4 right-4 bg-white/90 hover:bg-white text-gray-900 border border-gray-300 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 shadow-lg backdrop-blur-md tap-effect transition">
            <i class="fas fa-th"></i> Show all 8 photos
        </button>
    </div>

    <!-- ================= 3. LISTING CONTENT & STICKY BOOKING WIDGET ================= -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
        
        <!-- Left 2-Columns: Details & Amenities -->
        <div class="lg:col-span-2 space-y-8">
            
            <!-- Host Info & Room Type Highlights -->
            <div class="flex items-center justify-between pb-6 border-b border-gray-200">
                <div>
                    <h2 class="text-lg sm:text-xl font-bold text-gray-900">Hosted by Ramesh Kumar Sharma</h2>
                    <p class="text-xs sm:text-sm text-gray-500 mt-0.5">StayNest Verified Superhost • 4 years hosting • 98% response rate</p>
                </div>
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" alt="Host" class="w-14 h-14 rounded-full object-cover border-2 border-brand shadow-sm">
                    <div class="absolute -bottom-1 -right-1 bg-brand text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
            </div>

            <!-- Airbnb Signature Highlights List -->
            <div class="space-y-5 pb-6 border-b border-gray-200">
                <div class="flex items-start gap-4">
                    <i class="fas fa-key text-xl text-brand mt-1"></i>
                    <div>
                        <h3 class="font-bold text-sm text-gray-900">Self check-in with Biometric</h3>
                        <p class="text-xs text-gray-500">Check yourself in with the smart biometric fingerprint scanner.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <i class="fas fa-utensils text-xl text-brand mt-1"></i>
                    <div>
                        <h3 class="font-bold text-sm text-gray-900">3 Fresh Meals Included Daily</h3>
                        <p class="text-xs text-gray-500">Hygienic home-cooked breakfast, lunch, and dinner prepared by verified chefs.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <i class="fas fa-wifi text-xl text-brand mt-1"></i>
                    <div>
                        <h3 class="font-bold text-sm text-gray-900">High-Speed 150 Mbps Fiber WiFi</h3>
                        <p class="text-xs text-gray-500">Ideal for remote work and online study sessions with power backup.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <i class="fas fa-calendar-xmark text-xl text-brand mt-1"></i>
                    <div>
                        <h3 class="font-bold text-sm text-gray-900">Free cancellation within 48 hours</h3>
                        <p class="text-xs text-gray-500">Get a full refund if your plans change before moving in.</p>
                    </div>
                </div>
            </div>

            <!-- StayCover Protection Badge -->
            <div class="bg-brand-50 rounded-2xl p-5 border border-brand-100">
                <div class="flex items-center gap-2 mb-2">
                    <i class="fas fa-shield-heart text-brand text-xl"></i>
                    <span class="font-extrabold text-gray-900 text-sm">Stay<span class="text-brand">Cover</span> Protection Included</span>
                </div>
                <p class="text-xs text-gray-600 leading-relaxed">Every StayNest booking includes free protection from Host cancellations, listing inaccuracies, and other issues like trouble checking in.</p>
            </div>

            <!-- About this PG -->
            <div class="pb-6 border-b border-gray-200">
                <h3 class="text-lg font-bold text-gray-900 mb-3">About this space</h3>
                <p class="text-sm text-gray-700 leading-relaxed">
                    Sunrise Premium PG is a newly renovated luxury student and corporate living space situated in Sector 62, Noida. Located within 5 minutes walk from the Sector 62 Metro Station and major IT parks including Candor TechSpace and Unitech Infospace.
                </p>
                <p class="text-sm text-gray-700 leading-relaxed mt-3">
                    Equipped with spacious air-conditioned rooms, ergonomic study desks, attached modern washrooms, daily housekeeping, 24/7 security with CCTV surveillance, and unlimited high-speed fiber internet.
                </p>
            </div>

            <!-- Sleeping Arrangements / Room Types -->
            <div class="pb-6 border-b border-gray-200">
                <h3 class="text-lg font-bold text-gray-900 mb-4">Available Room Arrangements</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <!-- Twin Sharing -->
                    <div class="border border-gray-200 hover:border-brand rounded-2xl p-5 bg-white transition shadow-xs">
                        <div class="flex items-center gap-3 mb-3">
                            <i class="fas fa-bed text-2xl text-brand"></i>
                            <i class="fas fa-bed text-2xl text-brand"></i>
                        </div>
                        <h4 class="font-bold text-sm text-gray-900">Twin Sharing Room</h4>
                        <p class="text-xs text-gray-500 mb-3">2 Single Beds • Attached Bathroom • Balcony</p>
                        <div class="flex items-center justify-between pt-3 border-t border-gray-100">
                            <div>
                                <span class="text-xs text-gray-500 line-through">₹10,000</span>
                                <div class="text-base font-bold text-gray-900">₹8,500 <span class="text-xs font-normal text-gray-500">/mo</span></div>
                            </div>
                            <a href="{{ route('user.bookings') }}" class="bg-brand text-white text-xs font-bold px-4 py-2 rounded-xl tap-effect">Select</a>
                        </div>
                    </div>

                    <!-- Single Private Room -->
                    <div class="border border-gray-200 hover:border-brand rounded-2xl p-5 bg-white transition shadow-xs">
                        <div class="flex items-center gap-3 mb-3">
                            <i class="fas fa-bed text-2xl text-brand"></i>
                        </div>
                        <h4 class="font-bold text-sm text-gray-900">Private Single Room</h4>
                        <p class="text-xs text-gray-500 mb-3">1 Queen Bed • Private Attached Bathroom</p>
                        <div class="flex items-center justify-between pt-3 border-t border-gray-100">
                            <div>
                                <span class="text-xs text-gray-500 line-through">₹15,000</span>
                                <div class="text-base font-bold text-gray-900">₹12,500 <span class="text-xs font-normal text-gray-500">/mo</span></div>
                            </div>
                            <a href="{{ route('user.bookings') }}" class="bg-brand text-white text-xs font-bold px-4 py-2 rounded-xl tap-effect">Select</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- What this place offers (Amenities) -->
            <div class="pb-6 border-b border-gray-200">
                <h3 class="text-lg font-bold text-gray-900 mb-4">What this stay offers</h3>
                <div class="grid grid-cols-2 gap-y-3.5 gap-x-6 text-sm text-gray-800">
                    <div class="flex items-center gap-3"><i class="fas fa-wifi text-brand text-base w-5"></i> High-Speed WiFi (150 Mbps)</div>
                    <div class="flex items-center gap-3"><i class="fas fa-utensils text-brand text-base w-5"></i> 3 Meals (Breakfast, Lunch, Dinner)</div>
                    <div class="flex items-center gap-3"><i class="fas fa-snowflake text-brand text-base w-5"></i> Air conditioning in all rooms</div>
                    <div class="flex items-center gap-3"><i class="fas fa-shield-alt text-brand text-base w-5"></i> 24x7 CCTV & Security Guard</div>
                    <div class="flex items-center gap-3"><i class="fas fa-broom text-brand text-base w-5"></i> Daily Room Cleaning</div>
                    <div class="flex items-center gap-3"><i class="fas fa-tshirt text-brand text-base w-5"></i> Washing Machine & Laundry Area</div>
                    <div class="flex items-center gap-3"><i class="fas fa-bolt text-brand text-base w-5"></i> 24/7 Power Backup Generator</div>
                    <div class="flex items-center gap-3"><i class="fas fa-car text-brand text-base w-5"></i> Free Bike & Car Parking</div>
                </div>
            </div>

            <!-- Location Map Card -->
            <div>
                <h3 class="text-lg font-bold text-gray-900 mb-2">Where you'll be</h3>
                <p class="text-xs text-gray-500 mb-4">Sector 62, Noida, Uttar Pradesh • 0.3 km to Blue Line Metro</p>
                <div class="relative h-64 rounded-3xl overflow-hidden shadow-sm border border-gray-200">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14013.43477148564!2d77.3598511!3d28.6276805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5456ef36d9f%3A0x3b7191b1286136c8!2sSector%2062%2C%20Noida%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1690000000000!5m2!1sen!2sin" 
                        class="w-full h-full border-0" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>

        </div>

        <!-- Right 1-Column: Sticky Airbnb Reservation Card (Desktop) -->
        <div class="hidden lg:block">
            <div class="sticky top-28 bg-white rounded-3xl p-6 shadow-xl border border-gray-200 space-y-5">
                <div class="flex justify-between items-baseline">
                    <div>
                        <span class="text-2xl font-extrabold text-gray-900">₹8,500</span>
                        <span class="text-xs text-gray-500 font-normal">/ month</span>
                    </div>
                    <div class="flex items-center gap-1 text-xs font-bold text-gray-900">
                        <i class="fas fa-star text-yellow-400"></i>
                        <span>4.89</span>
                        <span class="text-gray-400 font-normal">• 120 reviews</span>
                    </div>
                </div>

                <!-- Reservation Form Box -->
                <div class="border border-gray-300 rounded-2xl overflow-hidden divide-y divide-gray-200">
                    <div class="grid grid-cols-2 divide-x divide-gray-200">
                        <div class="p-3">
                            <label class="block text-[10px] font-bold uppercase text-gray-700">Move-in Date</label>
                            <input type="date" value="{{ date('Y-m-d') }}" class="w-full text-xs font-semibold text-gray-800 bg-transparent focus:outline-none cursor-pointer">
                        </div>
                        <div class="p-3">
                            <label class="block text-[10px] font-bold uppercase text-gray-700">Duration</label>
                            <select class="w-full text-xs font-semibold text-gray-800 bg-transparent focus:outline-none cursor-pointer">
                                <option>3+ Months</option>
                                <option>6+ Months</option>
                                <option>11 Months</option>
                            </select>
                        </div>
                    </div>
                    <div class="p-3">
                        <label class="block text-[10px] font-bold uppercase text-gray-700">Room Type</label>
                        <select class="w-full text-xs font-semibold text-gray-800 bg-transparent focus:outline-none cursor-pointer">
                            <option>Twin Sharing (₹8,500/mo)</option>
                            <option>Single Private Room (₹12,500/mo)</option>
                            <option>Triple Sharing (₹6,500/mo)</option>
                        </select>
                    </div>
                </div>

                <!-- Reserve CTA Button -->
                <a href="{{ route('user.bookings') }}" class="block w-full bg-gradient-to-r from-brand to-brand-dark hover:shadow-lg hover:shadow-brand/30 text-white font-bold py-3.5 rounded-2xl text-center tap-effect transition text-sm">
                    Reserve This Room
                </a>

                <p class="text-center text-xs text-gray-500">You won't be charged yet</p>

                <!-- Pricing Breakdown Table -->
                <div class="space-y-2.5 pt-4 border-t border-gray-100 text-xs text-gray-600">
                    <div class="flex justify-between">
                        <span>₹8,500 x 1 month rent</span>
                        <span class="font-semibold text-gray-900">₹8,500</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Security Deposit (Refundable)</span>
                        <span class="font-semibold text-gray-900">₹4,000</span>
                    </div>
                    <div class="flex justify-between text-green-600 font-semibold">
                        <span>Zero Brokerage Discount</span>
                        <span>-₹2,500</span>
                    </div>
                    <div class="flex justify-between pt-3 border-t border-gray-200 text-sm font-bold text-gray-900">
                        <span>Total Initial Payment</span>
                        <span>₹12,500</span>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

<!-- Mobile Fixed Bottom Reservation Bar -->
<div class="md:hidden fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-3.5 z-40 flex items-center justify-between shadow-lg">
    <div>
        <div class="text-base font-extrabold text-gray-900">₹8,500<span class="text-xs font-normal text-gray-500">/mo</span></div>
        <div class="text-[10px] text-gray-500 font-medium">Twin Sharing • Meals Inc.</div>
    </div>
    <a href="{{ route('user.bookings') }}" class="bg-gradient-to-r from-brand to-brand-dark text-white font-bold px-6 py-2.5 rounded-xl text-xs tap-effect shadow-md shadow-brand/30">
        Reserve Room
    </a>
</div>
@endsection

@push('scripts')
<script>
    function toggleSaveDetail(btn) {
        const icon = btn.querySelector('i');
        const label = document.getElementById('saveLabel');
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            if (label) label.innerText = 'Saved';
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            if (label) label.innerText = 'Save';
        }
    }
</script>
@endpush
