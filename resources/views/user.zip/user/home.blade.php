@extends('user.layouts.app')

@section('title', 'StayNest - Find PG & Co-living Spaces Across India')

@push('styles')
<style>
    .category-tab {
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        border-bottom: 2px solid transparent;
    }
    .category-tab:hover {
        border-bottom-color: #e5e7eb;
        opacity: 1;
    }
    .category-tab.active {
        border-bottom-color: #4bb59d;
        color: #111827;
        opacity: 1;
    }
    .airbnb-card {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .airbnb-card:hover {
        transform: translateY(-2px);
    }
</style>
@endpush

@section('content')
<div class="w-full">

    <!-- ================= 1. AIRBNB-STYLE CATEGORY ICONS BAR (DESKTOP & MOBILE) ================= -->
    <div class="bg-white border-b border-gray-100 sticky top-14 md:top-20 z-40 shadow-xs">
        <div class="max-w-7xl mx-auto px-4 md:px-6">
            <div class="flex items-center gap-6 md:gap-8 overflow-x-auto no-scrollbar py-3">
                <button onclick="setHomeCategory(this, 'all')" class="category-tab active flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-city text-lg text-brand"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">All PGs</span>
                </button>
                <button onclick="setHomeCategory(this, 'boys')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-male text-lg text-blue-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Boys PG</span>
                </button>
                <button onclick="setHomeCategory(this, 'girls')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-female text-lg text-pink-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Girls PG</span>
                </button>
                <button onclick="setHomeCategory(this, 'coliving')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-users text-lg text-purple-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Co-living</span>
                </button>
                <button onclick="setHomeCategory(this, 'metro')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-train-subway text-lg text-emerald-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Near Metro</span>
                </button>
                <button onclick="setHomeCategory(this, 'food')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-utensils text-lg text-orange-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Meals Included</span>
                </button>
                <button onclick="setHomeCategory(this, 'ac')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-snowflake text-lg text-cyan-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">AC Rooms</span>
                </button>
                <button onclick="setHomeCategory(this, 'budget')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-wallet text-lg text-green-600"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Under ₹8k</span>
                </button>
                <button onclick="setHomeCategory(this, 'gym')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-dumbbell text-lg text-indigo-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">With Gym</span>
                </button>
                <button onclick="setHomeCategory(this, 'top')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-star text-lg text-yellow-500"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Top Rated</span>
                </button>
                <button onclick="setHomeCategory(this, 'verified')" class="category-tab flex flex-col items-center gap-1.5 pb-2 min-w-fit opacity-70 hover:opacity-100 transition cursor-pointer">
                    <i class="fas fa-shield-halved text-lg text-brand"></i>
                    <span class="text-xs font-semibold whitespace-nowrap">Verified Only</span>
                </button>
            </div>
        </div>
    </div>

    <!-- ================= 2. DESKTOP HERO & AIRBNB-STYLE SEARCH WIDGET ================= -->
    <div class="hidden md:block max-w-7xl mx-auto px-6 pt-6 pb-2">
        <div class="relative rounded-3xl overflow-hidden h-[360px] bg-slate-900 mb-8 shadow-xl">
            <img src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80" alt="StayNest PG" class="w-full h-full object-cover opacity-60">
            <div class="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-900/40 to-transparent"></div>
            <div class="absolute inset-0 flex flex-col justify-center px-12 text-white max-w-2xl">
                <div class="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-semibold w-fit mb-3 border border-white/20">
                    <i class="fas fa-check-circle text-brand"></i> 10,000+ Verified Beds • Zero Brokerage
                </div>
                <h1 class="text-4xl lg:text-5xl font-extrabold tracking-tight mb-3 leading-tight">
                    Find your next home <br><span class="text-brand">away from home</span>
                </h1>
                <p class="text-sm text-gray-200 mb-6">Explore curated student & working professional PGs across India's top tech hubs.</p>
                <div class="flex items-center gap-3">
                    <a href="{{ route('user.search') }}" class="bg-gradient-to-r from-brand to-brand-dark text-white font-bold px-6 py-3 rounded-2xl shadow-lg shadow-brand/30 hover:shadow-brand/50 tap-effect transition text-sm">
                        Explore All Stays <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                    <a href="{{ route('user.list-property') }}" class="bg-white/20 hover:bg-white/30 backdrop-blur-md text-white font-semibold px-5 py-3 rounded-2xl tap-effect transition text-sm">
                        List Your PG Free
                    </a>
                </div>
            </div>
        </div>

        <!-- Airbnb-Style Floating Segmented Search Box -->
        <div class="bg-white rounded-3xl p-4 shadow-xl border border-gray-100 -mt-16 relative z-10 max-w-5xl mx-auto mb-10">
            <form action="{{ route('user.search') }}" method="GET" class="grid grid-cols-1 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-gray-100 gap-2 md:gap-0 items-center">
                <!-- 1. Where -->
                <div class="px-4 py-2 hover:bg-gray-50 rounded-2xl transition cursor-pointer">
                    <label class="block text-[11px] font-bold text-gray-900 uppercase tracking-wider">Where</label>
                    <input type="text" name="city" placeholder="Search city or locality..." class="w-full text-sm font-medium text-gray-800 placeholder-gray-400 bg-transparent focus:outline-none truncate">
                </div>

                <!-- 2. Gender / Room Type -->
                <div class="px-4 py-2 hover:bg-gray-50 rounded-2xl transition cursor-pointer">
                    <label class="block text-[11px] font-bold text-gray-900 uppercase tracking-wider">Room For</label>
                    <select name="gender" class="w-full text-sm font-medium text-gray-800 bg-transparent focus:outline-none appearance-none cursor-pointer">
                        <option value="">Any (Boys, Girls, Co-ed)</option>
                        <option value="BOYS">Boys PG</option>
                        <option value="GIRLS">Girls PG</option>
                        <option value="CO-ED">Co-living / Co-ed</option>
                    </select>
                </div>

                <!-- 3. Budget -->
                <div class="px-4 py-2 hover:bg-gray-50 rounded-2xl transition cursor-pointer">
                    <label class="block text-[11px] font-bold text-gray-900 uppercase tracking-wider">Budget</label>
                    <select name="budget" class="w-full text-sm font-medium text-gray-800 bg-transparent focus:outline-none appearance-none cursor-pointer">
                        <option value="">Any Monthly Rent</option>
                        <option value="8000">Under ₹8,000 / mo</option>
                        <option value="10000">Under ₹10,000 / mo</option>
                        <option value="12000">Under ₹12,000 / mo</option>
                        <option value="15000">Under ₹15,000 / mo</option>
                    </select>
                </div>

                <!-- 4. Search CTA Button -->
                <div class="pl-4 pr-2 py-1 flex items-center justify-between">
                    <div>
                        <span class="text-[11px] font-bold text-gray-900 uppercase tracking-wider block">Amenities</span>
                        <span class="text-xs text-gray-500 font-medium">WiFi • Food • AC</span>
                    </div>
                    <button type="submit" class="w-12 h-12 rounded-full bg-gradient-to-r from-brand to-brand-dark text-white flex items-center justify-center shadow-lg shadow-brand/40 hover:scale-105 transition tap-effect flex-shrink-0">
                        <i class="fas fa-search text-base"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- ================= 3. POPULAR CITIES PILLS (QUICK ACCESS) ================= -->
    <div class="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-2 mb-4">
        <div class="flex items-center gap-2 overflow-x-auto no-scrollbar">
            <span class="text-xs font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap">Explore:</span>
            <a href="{{ route('user.search') }}?city=Noida" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Noida</a>
            <a href="{{ route('user.search') }}?city=Bangalore" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Bangalore</a>
            <a href="{{ route('user.search') }}?city=Delhi" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Delhi</a>
            <a href="{{ route('user.search') }}?city=Mumbai" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Mumbai</a>
            <a href="{{ route('user.search') }}?city=Gurugram" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Gurugram</a>
            <a href="{{ route('user.search') }}?city=Hyderabad" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Hyderabad</a>
            <a href="{{ route('user.search') }}?city=Pune" class="px-4 py-1.5 bg-white border border-gray-200 hover:border-brand hover:text-brand text-gray-700 text-xs font-semibold rounded-full whitespace-nowrap tap-effect transition shadow-xs">Pune</a>
        </div>
    </div>

    <!-- ================= 4. SECTION: PG NEAR ME (AIRBNB CARD DESIGN) ================= -->
    <section class="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 mb-10">
        <div class="flex justify-between items-end mb-4">
            <div>
                <h2 class="text-lg md:text-2xl font-bold text-gray-900">Stays Near You</h2>
                <p class="text-xs md:text-sm text-gray-500 mt-0.5">Top-rated verified PGs within 2 km of your location</p>
            </div>
            <a href="{{ route('user.search') }}" class="text-xs md:text-sm font-bold text-brand hover:underline flex items-center gap-1">
                Show all <i class="fas fa-chevron-right text-[10px]"></i>
            </a>
        </div>

        <!-- Airbnb-Style Responsive Grid (2-Cols Mobile, 4-Cols Desktop) -->
        <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
            @foreach ([
                ['image' => 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Sector 62, Noida', 'subtitle' => '0.3 km to Metro Station', 'type' => 'Boys • Meals Included', 'price' => '₹8,500', 'rating' => '4.89', 'reviews' => '120', 'badge' => 'Guest favourite'],
                ['image' => 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Indiranagar, Bangalore', 'subtitle' => '0.5 km to Metro', 'type' => 'Girls • Food & Security', 'price' => '₹9,999', 'rating' => '4.95', 'reviews' => '98', 'badge' => 'Guest favourite'],
                ['image' => 'https://images.unsplash.com/photo-1505691938895-1758d7feb511?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'HSR Layout, Bangalore', 'subtitle' => '1.2 km to Tech Park', 'type' => 'Co-living • Gym & WiFi', 'price' => '₹11,500', 'rating' => '4.78', 'reviews' => '75', 'badge' => 'Popular'],
                ['image' => 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Saket, New Delhi', 'subtitle' => '0.8 km to Metro Station', 'type' => 'Boys • AC Room', 'price' => '₹10,000', 'rating' => '4.82', 'reviews' => '85', 'badge' => 'StayNest Verified'],
            ] as $card)
                <a href="{{ route('user.detail') }}" class="airbnb-card group block text-gray-900">
                    <div class="relative aspect-square rounded-2xl overflow-hidden mb-2.5 bg-gray-100 shadow-xs">
                        <img src="{{ $card['image'] }}" alt="{{ $card['title'] }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                        
                        <!-- Guest Favourite / Verified Badge -->
                        <div class="absolute top-3 left-3 bg-white/90 backdrop-blur-md text-gray-900 text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                            <i class="fas fa-crown text-amber-500 text-[10px]"></i> {{ $card['badge'] }}
                        </div>

                        <!-- Heart Save Button -->
                        <button onclick="event.preventDefault(); toggleCardHeart(this);" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 backdrop-blur-sm flex items-center justify-center text-white tap-effect transition" title="Save to Wishlist">
                            <i class="far fa-heart text-sm"></i>
                        </button>

                        <!-- Carousel dots placeholder -->
                        <div class="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1">
                            <div class="w-1.5 h-1.5 rounded-full bg-white"></div>
                            <div class="w-1.5 h-1.5 rounded-full bg-white/50"></div>
                            <div class="w-1.5 h-1.5 rounded-full bg-white/50"></div>
                        </div>
                    </div>

                    <!-- Airbnb Card Typography -->
                    <div class="flex justify-between items-start text-xs sm:text-sm font-bold text-gray-900">
                        <span class="truncate pr-2">{{ $card['title'] }}</span>
                        <div class="flex items-center gap-1 flex-shrink-0 text-xs font-semibold">
                            <i class="fas fa-star text-xs text-yellow-400"></i>
                            <span>{{ $card['rating'] }}</span>
                        </div>
                    </div>
                    <p class="text-[11px] sm:text-xs text-gray-500 truncate">{{ $card['subtitle'] }}</p>
                    <p class="text-[11px] sm:text-xs text-gray-500 truncate">{{ $card['type'] }}</p>
                    <div class="mt-1 text-xs sm:text-sm">
                        <span class="font-extrabold text-gray-900">{{ $card['price'] }}</span>
                        <span class="font-normal text-gray-500 text-xs">month</span>
                    </div>
                </a>
            @endforeach
        </div>
    </section>

    <!-- ================= 5. AIRBNB-STYLE EXPERIENCE PROMO BANNER ================= -->
    <section class="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 mb-10">
        <div class="bg-gradient-to-r from-teal-900 via-brand-dark to-slate-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden shadow-xl">
            <div class="relative z-10 max-w-xl">
                <span class="inline-block bg-brand/30 border border-brand/40 text-brand-light text-xs font-bold px-3 py-1 rounded-full mb-3 uppercase tracking-wider">
                    Zero Brokerage Assurance
                </span>
                <h3 class="text-2xl sm:text-4xl font-extrabold mb-3 leading-tight">
                    Direct bookings with verified property owners
                </h3>
                <p class="text-xs sm:text-sm text-gray-200 mb-6">
                    Save up to ₹20,000 annually in brokerage charges. Transparent agreements, verified room photos, and instant move-in support.
                </p>
                <div class="flex flex-wrap gap-3">
                    <a href="{{ route('user.search') }}" class="bg-white text-gray-900 font-bold px-6 py-3 rounded-2xl hover:bg-gray-100 tap-effect transition text-xs sm:text-sm shadow-md">
                        Find PGs Near You
                    </a>
                    <a href="{{ route('user.about') }}" class="border border-white/40 hover:bg-white/10 text-white font-semibold px-5 py-3 rounded-2xl tap-effect transition text-xs sm:text-sm">
                        How It Works
                    </a>
                </div>
            </div>
            <div class="absolute right-0 bottom-0 opacity-10 sm:opacity-20 translate-x-12 translate-y-12">
                <i class="fas fa-house-chimney-user text-[260px] text-white"></i>
            </div>
        </div>
    </section>

    <!-- ================= 6. SECTION: RECENTLY ADDED (AIRBNB CARD DESIGN) ================= -->
    <section class="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 mb-10">
        <div class="flex justify-between items-end mb-4">
            <div>
                <h2 class="text-lg md:text-2xl font-bold text-gray-900">Recently Added Listings</h2>
                <p class="text-xs md:text-sm text-gray-500 mt-0.5">Fresh rooms and co-living spaces published this week</p>
            </div>
            <a href="{{ route('user.search') }}" class="text-xs md:text-sm font-bold text-brand hover:underline flex items-center gap-1">
                Show all <i class="fas fa-chevron-right text-[10px]"></i>
            </a>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
            @foreach ([
                ['image' => 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Koramangala, Bangalore', 'subtitle' => 'Added 2 hours ago', 'type' => 'Girls • Food & Cleaning', 'price' => '₹11,500', 'rating' => '4.88', 'reviews' => '110', 'badge' => 'New'],
                ['image' => 'https://images.unsplash.com/photo-1540518614846-7eded433c457?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Indiranagar, Bangalore', 'subtitle' => 'Added 5 hours ago', 'type' => 'Co-ed • Gym & Parking', 'price' => '₹13,000', 'rating' => '4.92', 'reviews' => '95', 'badge' => 'New'],
                ['image' => 'https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Chattarpur, Delhi', 'subtitle' => 'Added yesterday', 'type' => 'Girls • Metro 0.4 km', 'price' => '₹7,800', 'rating' => '4.70', 'reviews' => '42', 'badge' => 'New'],
                ['image' => 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'title' => 'Mehrauli, Delhi', 'subtitle' => 'Added yesterday', 'type' => 'Boys • Food Included', 'price' => '₹8,100', 'rating' => '4.75', 'reviews' => '50', 'badge' => 'New'],
            ] as $card)
                <a href="{{ route('user.detail') }}" class="airbnb-card group block text-gray-900">
                    <div class="relative aspect-square rounded-2xl overflow-hidden mb-2.5 bg-gray-100 shadow-xs">
                        <img src="{{ $card['image'] }}" alt="{{ $card['title'] }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                        
                        <div class="absolute top-3 left-3 bg-red-500 text-white text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                            <i class="fas fa-bolt text-[10px]"></i> {{ $card['badge'] }}
                        </div>

                        <button onclick="event.preventDefault(); toggleCardHeart(this);" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 backdrop-blur-sm flex items-center justify-center text-white tap-effect transition" title="Save">
                            <i class="far fa-heart text-sm"></i>
                        </button>
                    </div>

                    <div class="flex justify-between items-start text-xs sm:text-sm font-bold text-gray-900">
                        <span class="truncate pr-2">{{ $card['title'] }}</span>
                        <div class="flex items-center gap-1 flex-shrink-0 text-xs font-semibold">
                            <i class="fas fa-star text-xs text-yellow-400"></i>
                            <span>{{ $card['rating'] }}</span>
                        </div>
                    </div>
                    <p class="text-[11px] sm:text-xs text-gray-500 truncate">{{ $card['subtitle'] }}</p>
                    <p class="text-[11px] sm:text-xs text-gray-500 truncate">{{ $card['type'] }}</p>
                    <div class="mt-1 text-xs sm:text-sm">
                        <span class="font-extrabold text-gray-900">{{ $card['price'] }}</span>
                        <span class="font-normal text-gray-500 text-xs">month</span>
                    </div>
                </a>
            @endforeach
        </div>
    </section>

    <!-- ================= 7. AIRBNB-STYLE "HOST YOUR PG" CTA BANNER ================= -->
    <section class="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 mb-12">
        <div class="bg-gray-100 rounded-3xl p-6 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 border border-gray-200">
            <div class="max-w-xl">
                <span class="text-xs font-bold text-brand uppercase tracking-wider block mb-1">For Property Owners & PG Managers</span>
                <h3 class="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-2">List your PG on StayNest and fill beds faster</h3>
                <p class="text-xs sm:text-sm text-gray-600">Reach over 50,000+ students and corporate professionals looking for verified accommodations every month.</p>
            </div>
            <div class="flex items-center gap-3 flex-shrink-0">
                <a href="{{ route('user.list-property') }}" class="bg-brand hover:bg-brand-dark text-white font-bold px-6 py-3.5 rounded-2xl shadow-lg shadow-brand/30 tap-effect transition text-sm">
                    List Property Free
                </a>
                <a href="{{ route('user.pricing') }}" class="bg-white border border-gray-300 hover:border-gray-400 text-gray-800 font-semibold px-5 py-3.5 rounded-2xl tap-effect transition text-sm">
                    View Pricing
                </a>
            </div>
        </div>
    </section>

</div>
@endsection

@push('scripts')
<script>
    function setHomeCategory(btn, category) {
        document.querySelectorAll('.category-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    }

    function toggleCardHeart(btn) {
        const icon = btn.querySelector('i');
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas', 'text-red-500');
        } else {
            icon.classList.remove('fas', 'text-red-500');
            icon.classList.add('far');
        }
    }
</script>
@endpush
