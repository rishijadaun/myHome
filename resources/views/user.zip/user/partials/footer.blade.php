<!-- Mobile Airbnb-Style Bottom Tab Bar -->
<nav class="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-gray-200/80 z-50 pb-safe shadow-md">
    <div class="grid grid-cols-5 h-16 max-w-md mx-auto">
        <!-- 1. Explore / Search -->
        <a href="{{ route('user.home') }}" class="flex flex-col items-center justify-center gap-1 tap-effect group">
            <i class="fas fa-search text-lg {{ request()->routeIs('user.home') ? 'text-brand scale-110' : 'text-gray-400 group-hover:text-gray-600' }} transition-transform"></i>
            <span class="text-[10px] {{ request()->routeIs('user.home') ? 'text-brand font-bold' : 'text-gray-500 font-medium' }}">Explore</span>
        </a>

        <!-- 2. Wishlists / Saved -->
        <a href="{{ route('user.saved') }}" class="flex flex-col items-center justify-center gap-1 tap-effect group">
            <i class="fas fa-heart text-lg {{ request()->routeIs('user.saved') ? 'text-brand scale-110' : 'text-gray-400 group-hover:text-gray-600' }} transition-transform"></i>
            <span class="text-[10px] {{ request()->routeIs('user.saved') ? 'text-brand font-bold' : 'text-gray-500 font-medium' }}">Wishlists</span>
        </a>

        <!-- 3. Center Map Explore Button -->
        <a href="{{ route('user.location') }}" class="flex flex-col items-center justify-center gap-1 tap-effect -translate-y-3 group">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-brand to-brand-dark flex items-center justify-center text-white shadow-lg shadow-brand/40 group-hover:scale-105 transition-transform">
                <i class="fas fa-map-marked-alt text-base"></i>
            </div>
            <span class="text-[10px] font-bold text-gray-700 -mt-0.5">Map</span>
        </a>

        <!-- 4. Bookings / Trips -->
        <a href="{{ route('user.bookings') }}" class="flex flex-col items-center justify-center gap-1 tap-effect group">
            <i class="fas fa-suitcase-rolling text-lg {{ request()->routeIs('user.bookings') ? 'text-brand scale-110' : 'text-gray-400 group-hover:text-gray-600' }} transition-transform"></i>
            <span class="text-[10px] {{ request()->routeIs('user.bookings') ? 'text-brand font-bold' : 'text-gray-500 font-medium' }}">Bookings</span>
        </a>

        <!-- 5. Profile -->
        <a href="{{ route('user.profile') }}" class="flex flex-col items-center justify-center gap-1 tap-effect group">
            <i class="fas fa-user-circle text-lg {{ request()->routeIs('user.profile') ? 'text-brand scale-110' : 'text-gray-400 group-hover:text-gray-600' }} transition-transform"></i>
            <span class="text-[10px] {{ request()->routeIs('user.profile') ? 'text-brand font-bold' : 'text-gray-500 font-medium' }}">Profile</span>
        </a>
    </div>
</nav>

<!-- Desktop Airbnb-Style Global Footer Component -->
<footer class="hidden md:block bg-gray-50 border-t border-gray-200 text-gray-600 mt-16">
    <div class="max-w-7xl mx-auto px-6 py-12">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
            <!-- Col 1: Support -->
            <div>
                <h4 class="text-gray-900 font-bold mb-4 text-xs uppercase tracking-wider">Support</h4>
                <ul class="space-y-3 text-sm">
                    <li><a href="{{ route('user.contact') }}" class="hover:text-brand hover:underline transition">Help Centre</a></li>
                    <li><a href="{{ route('user.contact') }}" class="hover:text-brand hover:underline transition">StayCover Protection</a></li>
                    <li><a href="{{ route('user.about') }}" class="hover:text-brand hover:underline transition">Anti-discrimination</a></li>
                    <li><a href="{{ route('user.terms') }}" class="hover:text-brand hover:underline transition">Cancellation options</a></li>
                    <li><a href="{{ route('user.contact') }}" class="hover:text-brand hover:underline transition">Report concern</a></li>
                </ul>
            </div>

            <!-- Col 2: Hosting -->
            <div>
                <h4 class="text-gray-900 font-bold mb-4 text-xs uppercase tracking-wider">Hosting</h4>
                <ul class="space-y-3 text-sm">
                    <li><a href="{{ route('user.list-property') }}" class="hover:text-brand hover:underline transition">StayNest your PG</a></li>
                    <li><a href="{{ route('user.pricing') }}" class="hover:text-brand hover:underline transition">PG Protection & Verification</a></li>
                    <li><a href="{{ route('user.list-property') }}" class="hover:text-brand hover:underline transition">Hosting resources</a></li>
                    <li><a href="{{ route('user.about') }}" class="hover:text-brand hover:underline transition">Community forum</a></li>
                    <li><a href="{{ route('broker.login') }}" class="hover:text-brand hover:underline transition">Broker Partner Portal</a></li>
                </ul>
            </div>

            <!-- Col 3: Explore Cities -->
            <div>
                <h4 class="text-gray-900 font-bold mb-4 text-xs uppercase tracking-wider">Explore Cities</h4>
                <ul class="space-y-3 text-sm">
                    <li><a href="{{ route('user.search') }}" class="hover:text-brand hover:underline transition">PGs in Bangalore</a></li>
                    <li><a href="{{ route('user.search') }}" class="hover:text-brand hover:underline transition">PGs in Noida & Delhi NCR</a></li>
                    <li><a href="{{ route('user.search') }}" class="hover:text-brand hover:underline transition">PGs in Delhi</a></li>
                    <li><a href="{{ route('user.search') }}" class="hover:text-brand hover:underline transition">PGs in Mumbai</a></li>
                    <li><a href="{{ route('user.search') }}" class="hover:text-brand hover:underline transition">PGs in Gurugram</a></li>
                </ul>
            </div>

            <!-- Col 4: StayNest -->
            <div>
                <h4 class="text-gray-900 font-bold mb-4 text-xs uppercase tracking-wider">StayNest</h4>
                <ul class="space-y-3 text-sm">
                    <li><a href="{{ route('user.about') }}" class="hover:text-brand hover:underline transition">About Us</a></li>
                    <li><a href="{{ route('user.pricing') }}" class="hover:text-brand hover:underline transition">Pricing & Plans</a></li>
                    <li><a href="{{ route('user.privacy') }}" class="hover:text-brand hover:underline transition">Privacy Policy</a></li>
                    <li><a href="{{ route('user.terms') }}" class="hover:text-brand hover:underline transition">Terms of Service</a></li>
                    <li><a href="{{ route('admin.login') }}" class="hover:text-brand hover:underline transition">Admin Console</a></li>
                </ul>
            </div>
        </div>

        <!-- Footer Bottom Bar -->
        <div class="border-t border-gray-200 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
            <div class="flex flex-wrap items-center gap-3">
                <span class="font-medium">&copy; {{ date('Y') }} StayNest Technologies Inc.</span>
                <span>•</span>
                <a href="{{ route('user.privacy') }}" class="hover:underline hover:text-brand transition">Privacy</a>
                <span>•</span>
                <a href="{{ route('user.terms') }}" class="hover:underline hover:text-brand transition">Terms</a>
                <span>•</span>
                <a href="{{ route('user.about') }}" class="hover:underline hover:text-brand transition">Company details</a>
            </div>
            
            <div class="flex items-center gap-6">
                <div class="flex items-center gap-2 font-semibold text-gray-800">
                    <i class="fas fa-globe text-brand"></i>
                    <span>English (IN)</span>
                    <span class="ml-2 font-bold">₹ INR</span>
                </div>
                <div class="flex items-center gap-3 text-gray-600">
                    <a href="#" class="w-8 h-8 rounded-full hover:bg-gray-200 flex items-center justify-center transition"><i class="fab fa-facebook-f text-xs"></i></a>
                    <a href="#" class="w-8 h-8 rounded-full hover:bg-gray-200 flex items-center justify-center transition"><i class="fab fa-twitter text-xs"></i></a>
                    <a href="#" class="w-8 h-8 rounded-full hover:bg-gray-200 flex items-center justify-center transition"><i class="fab fa-instagram text-xs"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
