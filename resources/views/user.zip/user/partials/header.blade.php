<!-- Mobile App Airbnb-Style Header -->
<header class="md:hidden fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-xs">
    <div class="px-3 py-2.5">
        <div class="flex items-center gap-2">
            <!-- Airbnb-Style Search Pill Card (Full Width Tap Area) -->
            <a href="{{ route('user.search') }}" class="flex-1 flex items-center gap-3 bg-white border border-gray-200 hover:border-brand rounded-full py-2 px-3.5 shadow-sm tap-effect transition">
                <div class="w-8 h-8 rounded-full bg-brand/10 text-brand flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-search text-xs"></i>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-xs font-bold text-gray-900 truncate">Where to?</div>
                    <div class="text-[10px] text-gray-500 truncate">Anywhere • Any Budget • Verified PGs</div>
                </div>
            </a>

            <!-- Quick Filter / Map Toggle Button -->
            <a href="{{ route('user.search') }}" class="w-10 h-10 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center text-gray-700 hover:text-brand hover:border-brand tap-effect shadow-xs flex-shrink-0" title="Filters">
                <i class="fas fa-sliders-h text-xs"></i>
            </a>

            <!-- Profile Avatar -->
            <a href="{{ route('user.profile') }}" class="w-10 h-10 rounded-full bg-brand-light text-brand flex items-center justify-center tap-effect flex-shrink-0 border border-brand/20" title="Profile">
                <i class="fas fa-user text-xs"></i>
            </a>
        </div>
    </div>
</header>

<!-- Desktop Airbnb-Style Header -->
<header class="hidden md:block bg-white border-b border-gray-100 sticky top-0 z-50 shadow-xs">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex justify-between items-center h-20">
            
            <!-- 1. Left: Brand Logo -->
            <div class="flex items-center">
                <a href="{{ route('user.home') }}" class="flex items-center gap-2.5 cursor-pointer tap-effect">
                    <div class="w-10 h-10 bg-gradient-to-br from-brand to-brand-dark rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-brand/25">
                        <i class="fas fa-home"></i>
                    </div>
                    <span class="font-extrabold text-2xl text-gray-900 tracking-tight">Stay<span class="text-brand">Nest</span></span>
                </a>
            </div>

            <!-- 2. Center: Iconic Airbnb-Style Compact Search Pill Bar -->
            <div class="flex items-center">
                <a href="{{ route('user.search') }}" class="flex items-center border border-gray-200 hover:shadow-md rounded-full py-2 px-4 shadow-xs transition-all duration-200 bg-white hover:border-gray-300 group cursor-pointer divide-x divide-gray-200">
                    <div class="px-3 text-xs font-bold text-gray-800 group-hover:text-brand transition">Anywhere</div>
                    <div class="px-3 text-xs font-bold text-gray-800 group-hover:text-brand transition">Any Budget</div>
                    <div class="pl-3 pr-2 flex items-center gap-2">
                        <span class="text-xs text-gray-500 font-medium">Add preferences</span>
                        <div class="w-8 h-8 rounded-full bg-brand text-white flex items-center justify-center shadow-sm group-hover:bg-brand-dark transition">
                            <i class="fas fa-search text-xs"></i>
                        </div>
                    </div>
                </a>
            </div>

            <!-- 3. Right: Host Link, Globe, & Profile Pill Dropdown -->
            <div class="flex items-center gap-2">
                <a href="{{ route('user.list-property') }}" class="text-xs font-bold text-gray-700 hover:bg-gray-50 px-3.5 py-2.5 rounded-full transition tap-effect">
                    StayNest your PG
                </a>
                
                <a href="{{ route('user.location') }}" class="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-700 transition tap-effect" title="Explore on Map">
                    <i class="fas fa-globe text-sm"></i>
                </a>

                <!-- User Profile Menu Pill Button -->
                <div class="relative" id="userMenuContainer">
                    <button onclick="toggleUserDropdown()" class="flex items-center gap-2.5 border border-gray-200 hover:shadow-md rounded-full py-1.5 px-3 bg-white transition tap-effect cursor-pointer">
                        <i class="fas fa-bars text-gray-600 text-xs"></i>
                        <div class="w-7 h-7 bg-brand-light text-brand rounded-full flex items-center justify-center font-bold text-xs border border-brand/20">
                            <i class="fas fa-user text-[11px]"></i>
                        </div>
                    </button>

                    <!-- Profile Dropdown Menu -->
                    <div id="userDropdownMenu" class="hidden absolute right-0 mt-2 w-60 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50 transition-all transform origin-top-right">
                        <div class="px-4 py-2.5 border-b border-gray-100">
                            <p class="text-xs text-gray-500">Welcome to StayNest</p>
                            <p class="text-sm font-bold text-gray-900">Find Your Perfect PG</p>
                        </div>
                        <div class="py-1">
                            <a href="{{ route('user.login') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-sign-in-alt text-brand w-4"></i> Log In / Sign Up
                            </a>
                            <a href="{{ route('user.bookings') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-calendar-check text-brand w-4"></i> My Bookings
                            </a>
                            <a href="{{ route('user.saved') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-heart text-red-500 w-4"></i> Wishlists
                            </a>
                        </div>
                        <div class="border-t border-gray-100 py-1">
                            <a href="{{ route('user.list-property') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-plus-circle text-brand w-4"></i> List Property Free
                            </a>
                            <a href="{{ route('user.pricing') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-tag text-brand w-4"></i> Pricing Plans
                            </a>
                            <a href="{{ route('user.about') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-info-circle text-brand w-4"></i> About Us
                            </a>
                            <a href="{{ route('user.contact') }}" class="flex items-center gap-3 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition">
                                <i class="fas fa-headset text-brand w-4"></i> Help & Contact
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
    function toggleUserDropdown() {
        const menu = document.getElementById('userDropdownMenu');
        if (menu) {
            menu.classList.toggle('hidden');
        }
    }

    document.addEventListener('click', function(e) {
        const container = document.getElementById('userMenuContainer');
        const menu = document.getElementById('userDropdownMenu');
        if (container && menu && !container.contains(e.target)) {
            menu.classList.add('hidden');
        }
    });
</script>
