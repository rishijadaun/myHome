@extends('user.layouts.app')

@section('title', 'Your Wishlists - StayNest')

@push('styles')
<style>
    .airbnb-card {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .airbnb-card:hover {
        transform: translateY(-2px);
    }
</style>
@endpush

@section('content')
<div class="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 pt-6 pb-24 md:pb-16 w-full">

    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-gray-900">Wishlists</h1>
            <p class="text-xs sm:text-sm text-gray-500 mt-1">Properties you've saved for future stays</p>
        </div>
        <a href="{{ route('user.search') }}" class="text-xs sm:text-sm font-bold text-brand hover:underline flex items-center gap-1">
            Explore more <i class="fas fa-arrow-right text-[10px]"></i>
        </a>
    </div>

    <!-- Wishlists Grid (2-Cols Mobile, 4-Cols Desktop) -->
    <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 md:gap-6" id="savedGrid">
        
        <!-- Saved Item 1 -->
        <div class="airbnb-card saved-item group block text-gray-900 w-full relative transition-all duration-300">
            <div class="relative aspect-square rounded-2xl overflow-hidden mb-2.5 bg-gray-100 shadow-xs">
                <a href="{{ route('user.detail') }}" class="block w-full h-full">
                    <img src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Sunrise Premium PG" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                </a>
                <div class="absolute top-2.5 left-2.5 bg-white/90 backdrop-blur-md text-gray-900 text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                    <i class="fas fa-crown text-amber-500 text-[10px]"></i> Guest favourite
                </div>
                <button onclick="removeSavedItem(this)" class="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 hover:bg-white shadow-md flex items-center justify-center text-red-500 tap-effect transition" title="Remove from wishlist">
                    <i class="fas fa-heart text-sm"></i>
                </button>
            </div>
            <a href="{{ route('user.detail') }}">
                <div class="flex justify-between items-start text-xs sm:text-sm font-bold text-gray-900">
                    <span class="truncate pr-1">Sector 62, Noida</span>
                    <div class="flex items-center gap-1 flex-shrink-0 text-xs font-semibold">
                        <i class="fas fa-star text-xs text-yellow-400"></i>
                        <span>4.89</span>
                    </div>
                </div>
                <p class="text-[11px] sm:text-xs text-gray-500 truncate">Sunrise Premium • 1.2 km Metro</p>
                <p class="text-[11px] sm:text-xs text-gray-500 truncate">Boys • Food & AC Included</p>
                <div class="mt-1 text-xs sm:text-sm">
                    <span class="font-extrabold text-gray-900">₹8,500</span>
                    <span class="font-normal text-gray-500 text-xs">month</span>
                </div>
            </a>
        </div>

        <!-- Saved Item 2 -->
        <div class="airbnb-card saved-item group block text-gray-900 w-full relative transition-all duration-300">
            <div class="relative aspect-square rounded-2xl overflow-hidden mb-2.5 bg-gray-100 shadow-xs">
                <a href="{{ route('user.detail') }}" class="block w-full h-full">
                    <img src="https://images.unsplash.com/photo-1598928506311-c55ded91a20c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Aura Women's Stay" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                </a>
                <div class="absolute top-2.5 left-2.5 bg-white/90 backdrop-blur-md text-gray-900 text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                    <i class="fas fa-crown text-amber-500 text-[10px]"></i> Guest favourite
                </div>
                <button onclick="removeSavedItem(this)" class="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 hover:bg-white shadow-md flex items-center justify-center text-red-500 tap-effect transition" title="Remove from wishlist">
                    <i class="fas fa-heart text-sm"></i>
                </button>
            </div>
            <a href="{{ route('user.detail') }}">
                <div class="flex justify-between items-start text-xs sm:text-sm font-bold text-gray-900">
                    <span class="truncate pr-1">Indiranagar, Bangalore</span>
                    <div class="flex items-center gap-1 flex-shrink-0 text-xs font-semibold">
                        <i class="fas fa-star text-xs text-yellow-400"></i>
                        <span>4.95</span>
                    </div>
                </div>
                <p class="text-[11px] sm:text-xs text-gray-500 truncate">Aura Women's • 0.5 km Metro</p>
                <p class="text-[11px] sm:text-xs text-gray-500 truncate">Girls • 24x7 Security & WiFi</p>
                <div class="mt-1 text-xs sm:text-sm">
                    <span class="font-extrabold text-gray-900">₹9,999</span>
                    <span class="font-normal text-gray-500 text-xs">month</span>
                </div>
            </a>
        </div>

    </div>

    <!-- Empty State -->
    <div id="emptyWishlist" class="hidden text-center py-16">
        <div class="w-16 h-16 rounded-full bg-gray-100 text-gray-400 flex items-center justify-center text-2xl mx-auto mb-4">
            <i class="far fa-heart"></i>
        </div>
        <h3 class="text-lg font-bold text-gray-900 mb-1">Your wishlist is empty</h3>
        <p class="text-xs text-gray-500 mb-6">As you search, tap the heart icon on properties you like to save them here.</p>
        <a href="{{ route('user.search') }}" class="bg-brand text-white font-bold px-6 py-3 rounded-2xl tap-effect shadow-md text-xs sm:text-sm">
            Start Exploring
        </a>
    </div>

</div>
@endsection

@push('scripts')
<script>
    function removeSavedItem(btn) {
        const item = btn.closest('.saved-item');
        if (item) {
            item.style.opacity = '0';
            item.style.transform = 'scale(0.9)';
            setTimeout(() => {
                item.remove();
                const remaining = document.querySelectorAll('.saved-item');
                if (remaining.length === 0) {
                    const empty = document.getElementById('emptyWishlist');
                    if (empty) empty.classList.remove('hidden');
                }
            }, 250);
        }
    }
</script>
@endpush
